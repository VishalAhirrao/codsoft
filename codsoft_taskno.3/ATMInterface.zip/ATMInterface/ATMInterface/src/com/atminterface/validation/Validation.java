package com.atminterface.validation;

@SuppressWarnings("serial")
public class Validation extends Exception{
	public Validation(String s) {
		super(s);
	}
}
